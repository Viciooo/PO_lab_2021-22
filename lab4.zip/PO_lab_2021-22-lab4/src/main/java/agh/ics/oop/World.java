package agh.ics.oop;

import java.util.ArrayList;

public class World {
    public static void main(String[] args) {
        System.out.println("start");
        System.out.println("stop");
    }
}
